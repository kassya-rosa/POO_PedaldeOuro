/**
 * 
 */
/**
 * @author T1091501
 *
 */
module lojaPecas {
	requires java.sql;
}