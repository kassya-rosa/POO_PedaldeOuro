package br.com.ucb.DAOO;
//package br.com.ucb.DAO;
//
//import br.com.ucb.Conexao.*;
//
//public class CategoriaDAO {
//
//	ConexaoBD conexao = new ConexaoBD();
//	
//}
