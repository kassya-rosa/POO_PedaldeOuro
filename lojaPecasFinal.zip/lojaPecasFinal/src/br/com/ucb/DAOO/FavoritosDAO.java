package br.com.ucb.DAOO;
//package br.com.ucb.DAO;
//
//import br.com.ucb.Conexao.*;
//
//public class FavoritosDAO {
//
//	ConexaoBD conexao = new ConexaoBD();
//	
//}
