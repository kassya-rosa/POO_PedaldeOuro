package br.com.ucb.Bean;

public class Favoritos {

	
	
}
