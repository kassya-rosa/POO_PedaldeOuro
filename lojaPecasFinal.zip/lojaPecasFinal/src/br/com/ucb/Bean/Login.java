package br.com.ucb.Bean;

public class Login {

	String cpf;
	int id;
	
	public Login(String cpf, int id) {
		super();
		this.cpf = cpf;
		this.id = id;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	
	public void FazerLogin() {
		
		
		
	}
	
	
}
