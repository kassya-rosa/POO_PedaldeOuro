package br.com.ucb.Home;
import java.io.IOException;

public class Clear {

	public final static void clearConsole(){

        try{
            System.out.println("");
            System.out.println("");
            System.out.println("");
            System.out.println("");
            System.out.println("");
            System.out.println("");
            System.out.println("");
            System.out.println("");
            System.out.println("");
            System.out.println("");
            System.out.println("");
            System.out.println("");
            System.out.println("");
            System.out.println("");
            System.out.println("");
            System.out.println("");
            System.out.println("");
            System.out.println("");
        }
        catch (final Exception e){
        //  Tratar Exceptions
        }
    }
	
}
